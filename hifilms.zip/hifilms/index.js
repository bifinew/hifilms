var $ = function( id ) { return document.getElementById( id ); };
var img = '<img class="lazy" data-src=';
var aurl ="<a href='video.html?q=";
var wurl ="<a href='wshows.html?";
var ibb = "https://i.ibb.co/";
//refresh
function refresh(){
        window.location.reload("Refresh")
      }
//menu tab
function openNav() {
  $("myNav").style.width = "100%";
}
function closeNav() {
  $("myNav").style.width = "0%";
}

 //images
document.addEventListener("DOMContentLoaded",function(){var e=[].slice.call(document.querySelectorAll("img.lazy"));if("IntersectionObserver"in window){let n=new IntersectionObserver(function(e,t){e.forEach(function(e){if(e.isIntersecting){let t=e.target;t.src=t.dataset.src,t.classList.remove("lazy"),n.unobserve(t)}})});e.forEach(function(e){n.observe(e)})}});
document.addEventListener("DOMContentLoaded", function(event) {
document.querySelectorAll('img').forEach(function(img){
img.onerror = function(){this.style.display='none';};
})});

//on internet
const d = new Date();let time = d.getTime();let imgcss = `https://bifinew.github.io/default-css/nointernet.css?v=${time}`; var head = document.getElementsByTagName('HEAD')[0];var link = document.createElement('link');link.rel = 'stylesheet';link.type = 'text/css';link.href = imgcss; head.appendChild(link);

