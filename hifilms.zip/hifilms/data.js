var homes = [
//slider img
["cx4Xwae513g","Rv0D8Vx"],
["P5B0KVl3xa8","XyqW2cP"],
["XjuCjiiXNNs","qp2fvvZ"],
["y9cgtRYI6jM","cxhh1ZN"],
["ULEQb_l-N08","L5pBw7m"],
//movies
["bmla4w17Flo","4pj0Djx"],
["bmla4w17Flo","4pj0Djx"],
["bmla4w17Flo","4pj0Djx"],
["bmla4w17Flo","4pj0Djx"],
["bmla4w17Flo","4pj0Djx"],
["bmla4w17Flo","4pj0Djx"],
//Short Films
["bmla4w17Flo","4pj0Djx"],
["bmla4w17Flo","4pj0Djx"],
["bmla4w17Flo","4pj0Djx"],
["bmla4w17Flo","4pj0Djx"],
["bmla4w17Flo","4pj0Djx"],
["bmla4w17Flo","4pj0Djx"],
//Music Video
["bmla4w17Flo","4pj0Djx"],
["bmla4w17Flo","4pj0Djx"],
["bmla4w17Flo","4pj0Djx"],
["bmla4w17Flo","4pj0Djx"],
["bmla4w17Flo","4pj0Djx"],
["bmla4w17Flo","4pj0Djx"],
//kids
["bmla4w17Flo","4pj0Djx"],
["bmla4w17Flo","4pj0Djx"],
["bmla4w17Flo","4pj0Djx"],
["bmla4w17Flo","4pj0Djx"],
["bmla4w17Flo","4pj0Djx"],
["bmla4w17Flo","4pj0Djx"],
// web shows
["bmla4w17Flo","4pj0Djx","P9dc8Zv=5vAmkhO-wAQ&Couple=5vAmkhO-wAQ"],
["bmla4w17Flo","4pj0Djx","P9dc8Zv=5vAmkhO-wAQ&Couple=5vAmkhO-wAQ"],
["bmla4w17Flo","4pj0Djx","P9dc8Zv=5vAmkhO-wAQ&Couple=5vAmkhO-wAQ"],
["bmla4w17Flo","4pj0Djx","P9dc8Zv=5vAmkhO-wAQ&Couple=5vAmkhO-wAQ"],
["bmla4w17Flo","4pj0Djx","P9dc8Zv=5vAmkhO-wAQ&Couple=5vAmkhO-wAQ"],
["bmla4w17Flo","4pj0Djx","P9dc8Zv=5vAmkhO-wAQ&Couple=5vAmkhO-wAQ"]
]

// full list...........
var shows = [
["bmla4w17Flo","NWfWfHN","P9dc8Zv=5vAmkhO-wAQ&Couple=5vAmkhO-wAQ"],
["5vAmkhO-wAQ","P9dc8Zv","P9dc8Zv=5vAmkhO-wAQ&Couple=5vAmkhO-wAQ"],
["lji630IAUxQ","Byt3Qv6","P9dc8Zv=5vAmkhO-wAQ&Couple=5vAmkhO-wAQ"],
["cx4Xwae513g","Rv0D8Vx","P9dc8Zv=5vAmkhO-wAQ&Couple=5vAmkhO-wAQ"]
];

var movies = [
["bmla4w17Flo","NWfWfHN"],
["5vAmkhO-wAQ","P9dc8Zv"],
["lji630IAUxQ","Byt3Qv6"],
["cx4Xwae513g","Rv0D8Vx"],
["P5B0KVl3xa8","XyqW2cP"],
["XjuCjiiXNNs","qp2fvvZ"],
["y9cgtRYI6jM","cxhh1ZN"],
["ULEQb_l-N08","L5pBw7m"]
];

var films = [
["bmla4w17Flo","NWfWfHN"],
["5vAmkhO-wAQ","P9dc8Zv"],
["lji630IAUxQ","Byt3Qv6"],
["cx4Xwae513g","Rv0D8Vx"],
["P5B0KVl3xa8","XyqW2cP"],
["XjuCjiiXNNs","qp2fvvZ"],
["y9cgtRYI6jM","cxhh1ZN"],
["ULEQb_l-N08","L5pBw7m"]
];
var musics = [
["bmla4w17Flo","NWfWfHN"],
["5vAmkhO-wAQ","P9dc8Zv"],
["lji630IAUxQ","Byt3Qv6"],
["cx4Xwae513g","Rv0D8Vx"],
["P5B0KVl3xa8","XyqW2cP"],
["XjuCjiiXNNs","qp2fvvZ"],
["y9cgtRYI6jM","cxhh1ZN"],
["ULEQb_l-N08","L5pBw7m"]
];
var kids = [
["bmla4w17Flo","NWfWfHN"],
["5vAmkhO-wAQ","P9dc8Zv"],
["lji630IAUxQ","Byt3Qv6"],
["cx4Xwae513g","Rv0D8Vx"],
["P5B0KVl3xa8","XyqW2cP"],
["XjuCjiiXNNs","qp2fvvZ"],
["y9cgtRYI6jM","cxhh1ZN"],
["ULEQb_l-N08","L5pBw7m"]
];